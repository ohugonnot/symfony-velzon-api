<?php
if ( ! defined( 'WPINC' ) ) {
	die;
}

if ( !class_exists( 'Addify_Woo_Hide_Price_Admin' ) ) {

	class Addify_Woo_Hide_Price_Admin extends Addify_Woo_Hide_Price {

		public function __construct() {

			
			add_action( 'admin_enqueue_scripts', array( $this, 'afwhp_admin_scripts' ) );
			//Custom meta boxes
			add_action( 'admin_init', array( $this, 'afwhp_register_metaboxes' ), 10 );
			add_action( 'save_post_addify_whp', array($this, 'afwhp_meta_box_save' ));
			add_filter( 'manage_addify_whp_posts_columns', array( $this, 'afwhp_custom_columns' ) );
			add_action( 'manage_addify_whp_posts_custom_column' , array($this, 'afwhp_custom_column'), 10, 2 );
			add_action( 'admin_menu', array( $this, 'afwhp_custom_menu_admin' ) );
			

			add_action('wp_ajax_afwhpsearchProducts', array($this, 'afwhpsearchProducts'));
		}

		public function afwhp_admin_scripts() {

			$screen = get_current_screen();
			if ( 'addify_whp' !== $screen->post_type ) {
				   return;
			}

			wp_enqueue_style( 'afwhp-adminc', plugins_url( '../assets/css/afwhp_admin.css', __FILE__ ), false, '1.0' );
			
			wp_enqueue_style( 'select2', plugins_url( '../assets/css/select2.css', __FILE__ ), false, '1.0' );
			wp_enqueue_script( 'select2', plugins_url( '../assets/js/select2.js', __FILE__ ), false, '1.0' );
			wp_enqueue_script( 'afwhp-adminj', plugins_url( '../assets/js/afwhp_admin.js', __FILE__ ), false, '1.0' );
			$afwhp_data = array(
				'admin_url'  => admin_url('admin-ajax.php'),
				'nonce' => wp_create_nonce('afwhp-ajax-nonce'),

			);
			wp_localize_script( 'afwhp-adminj', 'afwhp_php_vars', $afwhp_data );
			wp_enqueue_style('thickbox');
			wp_enqueue_script('thickbox');
			wp_enqueue_script('media-upload');
			wp_enqueue_media();
		}

		public function afwhp_register_metaboxes() {

			add_meta_box( 'afwhp-rule-settings', esc_html__( 'Rule Settings', 'addify_whp' ), array( $this, 'afwhp_rule_setting_callback' ), 'addify_whp', 'normal', 'high' );

		}

		public function afwhp_rule_setting_callback() { 
			global $post;
			wp_nonce_field( 'afwhp_fields_nonce', 'afwhp_field_nonce' );
			$afwhp_rule_type          = get_post_meta( intval($post->ID), 'afwhp_rule_type', true );
			$afwhp_rule_priority      = get_post_meta( intval($post->ID), 'afwhp_rule_priority', true );
			$afwhp_hide_products      = unserialize(get_post_meta( intval($post->ID), 'afwhp_hide_products', true ));
			$afwhp_hide_categories    = unserialize(get_post_meta( intval($post->ID), 'afwhp_hide_categories', true ));
			$afwhp_hide_user_role     = unserialize(get_post_meta( intval($post->ID), 'afwhp_hide_user_role', true ));
			$afwhp_hide_for_countries = unserialize(get_post_meta( intval($post->ID), 'afwhp_hide_for_countries', true ));
			$afwhp_is_hide_price      = get_post_meta( intval($post->ID), 'afwhp_is_hide_price', true );
			$afwhp_hide_price_text    = get_post_meta( intval($post->ID), 'afwhp_hide_price_text', true );
			$afwhp_is_hide_addtocart  = get_post_meta( intval($post->ID), 'afwhp_is_hide_addtocart', true );
			$afwhp_custom_button_text = get_post_meta( intval($post->ID), 'afwhp_custom_button_text', true );
			$afwhp_custom_button_link = get_post_meta( intval($post->ID), 'afwhp_custom_button_link', true );
			$afwhp_contact7_form      = get_post_meta( intval($post->ID), 'afwhp_contact7_form', true );

			

			?>
			<div class="afwhp_admin_main">
				<div class="afwhp_admin_main_left"><label><strong><?php echo esc_html__('Rule Type', 'addify_whp'); ?></strong></label></div>
				<div class="afwhp_admin_main_right">
					<select name="afwhp_rule_type" id="afwhp_rule_type" onchange="afwhp_getUserRole(this.value);">
						<option value="afwhp_for_guest_users" <?php echo selected(esc_attr($afwhp_rule_type), 'afwhp_for_guest_users'); ?>><?php echo esc_html__('Rule for Guest Users', 'addify_whp'); ?></option>
						<option value="afwhp_for_registered_users" <?php echo selected(esc_attr($afwhp_rule_type), 'afwhp_for_registered_users'); ?>><?php echo esc_html__('Rule for Registered Users', 'addify_whp'); ?></option>
					</select>
				</div>
			</div>

			<div class="afwhp_admin_main">

				<div class="afwhp_admin_main_left"><label><strong><?php echo esc_html__('Rule Priority', 'addify_whp'); ?></strong></label></div>

				<div class="afwhp_admin_main_right">

					<input type="number" min="1" max="10" name="afwhp_rule_priority" id="afwhp_rule_priority" value="<?php echo esc_attr($post->menu_order); ?>" class="text_box select_box_small" />
					<br><i><?php echo esc_html__('Provide value from high priority 1 to Low priority 10. If more than one rule are applied on same item rule with high priority will be applied.', 'addify_whp'); ?></i>

				</div>

			</div>

			<div class="afwhp_admin_main" id="quteurr">

				<div class="afwhp_admin_main_left"><label><strong><?php echo esc_html__('Rule for User Roles', 'addify_whp'); ?></strong></label></div>

				<div class="afwhp_admin_main_right">

					<select class="select_box wc-enhanced-select afwhp_hide_urole" name="afwhp_hide_user_role[]" id="afwhp_hide_user_role"  multiple='multiple'>

						<?php

						global $wp_roles;
						$roles = $wp_roles->get_names();
						foreach ($roles as $key => $value) {
							?>
							<option value="<?php echo esc_attr($key); ?>"
								<?php
								if (!empty($afwhp_hide_user_role) && in_array($key, $afwhp_hide_user_role)) {
									echo 'selected';
								}
								?>
							>
								<?php 
								echo esc_attr($value);
								?>
									
								</option>
						<?php } ?>

					</select>

				</div>

			</div>

			<div class="afwhp_admin_main">

				<div class="afwhp_admin_main_left"><label><strong><?php echo esc_html__('Hide for Countries', 'addify_whp'); ?></strong></label></div>

				<div class="afwhp_admin_main_right">

					<?php

						global $woocommerce;
						$countries_obj = new WC_Countries();
						$countries     = $countries_obj->__get('countries');

					?>

					<select class="select_box wc-enhanced-select afwhp_hide_urole" name="afwhp_hide_for_countries[]" id="afwhp_hide_for_countries"  multiple='multiple'>

						<?php foreach ($countries as $key => $value) { ?>
							<option value="<?php echo esc_attr($key); ?>" 
								<?php
								if (!empty($afwhp_hide_for_countries) && in_array($key, $afwhp_hide_for_countries)) {
									echo 'selected';
								}
								?>
								>

								<?php echo esc_attr($value); ?>
									
							</option>
						<?php } ?>

					</select>

				</div>

			</div>

			<div class="afwhp_admin_main">
				<div class="afwhp_admin_main_left"><label><strong><?php echo esc_html__('Apply on All Products', 'addify_role_price'); ?></strong></label></div>
				<div class="afwhp_admin_main_right">
					<?php
						$applied_on_all_products = get_post_meta($post->ID, 'afwhp_apply_on_all_products', true);
					?>
					<input type="checkbox" name="afwhp_apply_on_all_products" id="afwhp_apply_on_all_products" value="yes" <?php echo checked('yes', $applied_on_all_products); ?>>
					<p class="csp_msg"><?php echo esc_html__('Check this if you want to apply this rule on all products.', 'addify_role_price'); ?></p>
				</div>
			</div>

			<div class="afwhp_admin_main hide_all_pro">

				<div class="afwhp_admin_main_left"><label><strong><?php echo esc_html__('Rule for Selected Products', 'addify_whp'); ?></strong></label></div>

				<div class="afwhp_admin_main_right">
					<select class="select_box wc-enhanced-select afwhp_hide_products" name="afwhp_hide_products[]" id="afwhp_hide_products"  multiple='multiple'>
						<?php

						if (!empty($afwhp_hide_products)) {

							foreach ( $afwhp_hide_products as $pro) {

								$prod_post = get_post($pro);

								?>

									<option value="<?php echo intval($pro); ?>" selected="selected"><?php echo esc_attr($prod_post->post_title); ?></option>

								<?php 
							}
						}
						?>
					</select>
				</div>

			</div>


			<div class="afwhp_admin_main hide_all_pro">

				<div class="afwhp_admin_main_left"><label><strong><?php echo esc_html__('Rule for Selected Categories', 'addify_whp'); ?></strong></label></div>

				<div class="afwhp_admin_main_right">


					<div class="all_cats">
						<ul>
							<?php

							$pre_vals = $afwhp_hide_categories;

							$args = array(
								'taxonomy' => 'product_cat',
								'hide_empty' => false,
								'parent'   => 0
							);

							$product_cat = get_terms( $args );
							foreach ($product_cat as $parent_product_cat) {
								?>
								<li class="par_cat">
									<input type="checkbox" class="parent" name="afwhp_hide_categories[]" id="afwhp_hide_categories" value="<?php echo intval($parent_product_cat->term_id); ?>" 
									<?php 
									if (!empty($pre_vals) && in_array($parent_product_cat->term_id, $pre_vals)) { 
										echo 'checked';
									}
									?>
									/>
									<?php echo esc_attr($parent_product_cat->name); ?>

									<?php
									$child_args         = array(
										'taxonomy' => 'product_cat',
										'hide_empty' => false,
										'parent'   => intval($parent_product_cat->term_id)
									);
									$child_product_cats = get_terms( $child_args );
									if (!empty($child_product_cats)) {
										?>
										<ul>
											<?php foreach ($child_product_cats as $child_product_cat) { ?>
												<li class="child_cat">
													<input type="checkbox" class="child parent" name="afwhp_hide_categories[]" id="afwhp_hide_categories" value="<?php echo intval($child_product_cat->term_id); ?>" 
													<?php
													if (!empty($pre_vals) &&in_array($child_product_cat->term_id, $pre_vals)) { 
														echo 'checked';
													}
													?>
													/>
													<?php echo esc_attr($child_product_cat->name); ?>

													<?php
													//2nd level
													$child_args2 = array(
														'taxonomy' => 'product_cat',
														'hide_empty' => false,
														'parent'   => intval($child_product_cat->term_id)
													);

													$child_product_cats2 = get_terms( $child_args2 );
													if (!empty($child_product_cats2)) {
														?>

														<ul>
															<?php foreach ($child_product_cats2 as $child_product_cat2) { ?>

																<li class="child_cat">
																	<input type="checkbox" class="child parent" name="afwhp_hide_categories[]" id="afwhp_hide_categories" value="<?php echo intval($child_product_cat2->term_id); ?>" 
																	<?php
																	if (!empty($pre_vals) &&in_array($child_product_cat2->term_id, $pre_vals)) {
																		echo 'checked';
																	}
																	?>
																	/>
																	<?php echo esc_attr($child_product_cat2->name); ?>


																	<?php
																	//3rd level
																	$child_args3 = array(
																		'taxonomy' => 'product_cat',
																		'hide_empty' => false,
																		'parent'   => intval($child_product_cat2->term_id)
																	);

																	$child_product_cats3 = get_terms( $child_args3 );
																	if (!empty($child_product_cats3)) {
																		?>

																		<ul>
																			<?php foreach ($child_product_cats3 as $child_product_cat3) { ?>

																				<li class="child_cat">
																					<input type="checkbox" class="child parent" name="afwhp_hide_categories[]" id="afwhp_hide_categories" value="<?php echo intval($child_product_cat3->term_id); ?>" 
																					<?php
																					if (!empty($pre_vals) &&in_array($child_product_cat3->term_id, $pre_vals)) {
																						echo 'checked';
																					}
																					?>
																					/>
																					<?php echo esc_attr($child_product_cat3->name); ?>


																					<?php
																					//4th level
																					$child_args4 = array(
																						'taxonomy' => 'product_cat',
																						'hide_empty' => false,
																						'parent'   => intval($child_product_cat3->term_id)
																					);

																					$child_product_cats4 = get_terms( $child_args4 );
																					if (!empty($child_product_cats4)) {
																						?>

																						<ul>
																							<?php foreach ($child_product_cats4 as $child_product_cat4) { ?>

																								<li class="child_cat">
																									<input type="checkbox" class="child parent" name="afwhp_hide_categories[]" id="afwhp_hide_categories" value="<?php echo intval($child_product_cat4->term_id); ?>"
																									<?php
																									if (!empty($pre_vals) &&in_array($child_product_cat4->term_id, $pre_vals)) {
																										echo 'checked';
																									}
																									?>
																									/>
																									<?php echo esc_attr($child_product_cat4->name); ?>


																									<?php
																									//5th level
																									$child_args5 = array(
																										'taxonomy' => 'product_cat',
																										'hide_empty' => false,
																										'parent'   => intval($child_product_cat4->term_id)
																									);

																									$child_product_cats5 = get_terms( $child_args5 );
																									if (!empty($child_product_cats5)) {
																										?>

																										<ul>
																											<?php foreach ($child_product_cats5 as $child_product_cat5) { ?>

																												<li class="child_cat">
																													<input type="checkbox" class="child parent" name="afwhp_hide_categories[]" id="afwhp_hide_categories" value="<?php echo intval($child_product_cat5->term_id); ?>" 
																													<?php
																													if (!empty($pre_vals) &&in_array($child_product_cat5->term_id, $pre_vals)) {
																														echo 'checked';
																													}
																													?>
																													/>
																													<?php echo esc_attr($child_product_cat5->name); ?>


																													<?php
																													//6th level
																													$child_args6 = array(
																														'taxonomy' => 'product_cat',
																														'hide_empty' => false,
																														'parent'   => intval($child_product_cat5->term_id)
																													);

																													$child_product_cats6 = get_terms( $child_args6 );
																													if (!empty($child_product_cats6)) {
																														?>

																														<ul>
																															<?php foreach ($child_product_cats6 as $child_product_cat6) { ?>

																																<li class="child_cat">
																																	<input type="checkbox" class="child" name="afwhp_hide_categories[]" id="afwhp_hide_categories" value="<?php echo intval($child_product_cat6->term_id); ?>" 
																																	<?php
																																	if (!empty($pre_vals) &&in_array($child_product_cat6->term_id, $pre_vals)) {
																																		echo 'checked';
																																	}
																																	?>
																																	/>
																																	<?php echo esc_attr($child_product_cat6->name); ?>
																																</li>

																															<?php } ?>
																														</ul>

																													<?php } ?>

																												</li>

																											<?php } ?>
																										</ul>

																									<?php } ?>


																								</li>

																							<?php } ?>
																						</ul>

																					<?php } ?>


																				</li>

																			<?php } ?>
																		</ul>

																	<?php } ?>

																</li>

															<?php } ?>
														</ul>

													<?php } ?>

												</li>
											<?php } ?>
										</ul>
									<?php } ?>

								</li>
								<?php
							}
							?>
						</ul>
					</div>


				</div>

			</div>


			<div class="afwhp_admin_main">

				<div class="afwhp_admin_main_left"><label><strong><?php echo esc_html__('Hide Price', 'addify_whp'); ?></strong></label></div>

				<div class="afwhp_admin_main_right">

					<select name="afwhp_is_hide_price" class="select_box_small" id="afwhp_is_hide_price" onchange="afwhp_HidePrice(this.value)">
						<option value="no" <?php echo selected('no', esc_attr($afwhp_is_hide_price )); ?>><?php echo esc_html__('No', 'addify_whp'); ?></option>
						<option value="yes" <?php echo selected('yes', esc_attr($afwhp_is_hide_price )); ?>><?php echo esc_html__('Yes', 'addify_whp'); ?></option>
					</select>

				</div>

			</div>

			<div class="afwhp_admin_main" id="hpircetext">

				<div class="afwhp_admin_main_left"><label><strong><?php echo esc_html__('Hide Price Text', 'addify_whp'); ?></strong></label></div>

				<div class="afwhp_admin_main_right">

					<?php
					if (!empty($afwhp_hide_price_text)) { 
						$afpricetext = $afwhp_hide_price_text;
					} else {
						$afpricetext = '';
					}
					?>
					
					<input type="text" name="afwhp_hide_price_text" id="afwhp_hide_price_text" value="<?php echo  esc_textarea( $afpricetext ); ?>" class="afwhp_input_class" />
					<br><i><?php echo esc_html__('Display the above text when price is hidden, e.g "Price is hidden"', 'addify_whp'); ?></i>

				</div>

			</div>

			<div class="afwhp_admin_main">

				<div class="afwhp_admin_main_left"><label><strong><?php echo esc_html__('Hide Add to Cart Button', 'addify_whp'); ?></strong></label></div>

				<div class="afwhp_admin_main_right">

					<select name="afwhp_is_hide_addtocart" class="select_box_small" id="afwhp_is_hide_addtocart" onchange="afwhp_HideCart(this.value)">
						<option value="no" <?php echo selected('no', esc_attr($afwhp_is_hide_addtocart )); ?>>
							<?php echo esc_html__('No', 'addify_whp'); ?>
								
							</option>
						<option value="yes" <?php echo selected('yes', esc_attr($afwhp_is_hide_addtocart )); ?>>
							<?php echo esc_html__('Yes', 'addify_whp'); ?>
							</option>
					</select>

				</div>

			</div>

			<div id="hpcarttext">
				<div class="afwhp_admin_main">

					<div class="afwhp_admin_main_left"><label><strong><?php echo esc_html__('Custom Button Label', 'addify_whp'); ?></strong></label></div>

					<div class="afwhp_admin_main_right">

						<?php
						if (!empty($afwhp_custom_button_text)) {
							$afcustombuttontext =  $afwhp_custom_button_text;
						} else {
							$afcustombuttontext = '';
						}
						?>
						<input type="text" name="afwhp_custom_button_text" id="afwhp_custom_button_text" value="<?php echo esc_html( $afcustombuttontext ); ?>" class="afwhp_input_class" />
						<br><i><?php echo esc_html__('Display the above label on custom button, e.g "Request a Quote"', 'addify_whp'); ?></i>

					</div>

				</div>

				<div class="afwhp_admin_main">

					<div class="afwhp_admin_main_left"><label><strong><?php echo esc_html__('Custom Button Link', 'addify_whp'); ?></strong></label></div>

					<div class="afwhp_admin_main_right">

						<?php
						if (!empty($afwhp_custom_button_link)) {
							$afcustombuttonlink =  $afwhp_custom_button_link;
						} else {
							$afcustombuttonlink = '';
						}
						?>
						<input type="text" name="afwhp_custom_button_link" id="afwhp_custom_button_link" value="<?php echo esc_html( $afcustombuttonlink ); ?>" class="afwhp_input_class" />
						<br><i><?php echo esc_html__('Link of the custom button, e.g "http://www.example.com"', 'addify_whp'); ?></i>

					</div>

				</div>

				<div class="afwhp_admin_main" id="or"><?php echo esc_html__('OR', 'addify_whp'); ?></div>

				<?php if ( is_plugin_active( 'contact-form-7/wp-contact-form-7.php' ) ) { ?>
					<div class="afwhp_admin_main">

						<div class="afwhp_admin_main_left"><label><strong><?php echo esc_html__('Display Form(Contact 7 Form)', 'addify_whp'); ?></strong></label></div>

						<div class="afwhp_admin_main_right">

							<?php
							if (!empty($afwhp_contact7_form)) {
								$hide_contact7_forms =  $afwhp_contact7_form;
							} else {
								$hide_contact7_forms = '';
							}
							?>
							
							<select name="afwhp_contact7_form" id="afwhp_contact7_form" class="select_box_small">
								<option value=""><?php echo esc_html__('Please Select Contact 7 Form', 'addify_whp'); ?></option>
								<?php 
								$posts = get_posts(array(
									'post_type'     => 'wpcf7_contact_form',
									'numberposts'   => -1
								));
								foreach ( $posts as $p ) {

									$selected = null;
									if ($hide_contact7_forms == $p->ID) {
										$selected = 'selected="selected"';
									}

									echo '<option ' . esc_attr($selected) . ' value="' . intval($p->ID) . '"' . selected($p->ID, $hide_contact7_forms) . '>' . esc_attr($p->post_title) . ' (' . intval($p->ID) . ')</option>';
								} 
								?>
							</select>

							<br><i><?php echo esc_html__('Select form that you want to use.', 'addify_whp'); ?></i>

						</div>

					</div>
				<?php } else { ?>

					<div class="afwhp_admin_main">

						<div class="afwhp_admin_main_left"></div>

						<div class="afwhp_admin_main_right">

							<p class="notes"><?php echo esc_html__('Please download and install Contact 7 Forms', 'addify_whp'); ?></p>

						</div>

					</div>

				<?php } ?>

			</div>

			<?php
		}

		public function afwhp_meta_box_save( $post_id ) {

			// return if we're doing an auto save
			if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
				return;
			}

			if ( get_post_status( $post_id ) === 'auto-draft' || get_post_status( $post_id ) === 'trash' ) {
				return;
			}

			// if our nonce isn't there, or we can't verify it, return
			if ( !isset( $_POST['afwhp_field_nonce'] ) || !wp_verify_nonce( sanitize_text_field($_POST['afwhp_field_nonce']), 'afwhp_fields_nonce' ) ) {
				die('Failed Security Check!');
			} 

			// if our current user can't edit this post, return
			if ( !current_user_can( 'edit_posts' ) ) {
				return;
			}

			remove_action( 'save_post_addify_whp', array($this, 'afwhp_meta_box_save'));

			if (isset($_POST['afwhp_rule_priority'])) {
				wp_update_post( array( 'ID' => intval($post_id), 'menu_order' => esc_attr(sanitize_text_field($_POST['afwhp_rule_priority']) ) ));
			}

			add_action( 'save_post_addify_whp', array($this, 'afwhp_meta_box_save' ));

			if ( isset( $_POST['afwhp_rule_type'] ) ) {
				update_post_meta( intval($post_id), 'afwhp_rule_type', esc_attr( sanitize_text_field($_POST['afwhp_rule_type']) ) );
			}

			if ( isset( $_POST['afwhp_hide_products'] ) ) {
				update_post_meta( intval($post_id), 'afwhp_hide_products', serialize(sanitize_meta('afwhp_hide_products', $_POST['afwhp_hide_products'], '') ));
			} else {
				update_post_meta( intval($post_id), 'afwhp_hide_products', '');
			}

			if ( isset( $_POST['afwhp_hide_categories'] ) ) {
				update_post_meta( intval($post_id), 'afwhp_hide_categories', serialize(sanitize_meta('afwhp_hide_categories', $_POST['afwhp_hide_categories'], '') ));
			} else {
				update_post_meta( intval($post_id), 'afwhp_hide_categories', '');
			}

			if ( isset( $_POST['afwhp_apply_on_all_products'] ) ) {
				update_post_meta( intval($post_id), 'afwhp_apply_on_all_products', esc_attr( sanitize_text_field($_POST['afwhp_apply_on_all_products']) ) );
			} else {

				update_post_meta( intval($post_id), 'afwhp_apply_on_all_products', 'no' );	
			}

			

			if ( isset( $_POST['afwhp_hide_user_role'] ) ) {
				update_post_meta( intval($post_id), 'afwhp_hide_user_role', serialize(sanitize_meta('afwhp_hide_user_role', $_POST['afwhp_hide_user_role'], '') ));
			} else {
				update_post_meta( intval($post_id), 'afwhp_hide_user_role', '');
			}

			if ( isset( $_POST['afwhp_hide_for_countries'] ) ) {
				update_post_meta( intval($post_id), 'afwhp_hide_for_countries', serialize(sanitize_meta('afwhp_hide_for_countries', $_POST['afwhp_hide_for_countries'], '') ));
			} else {
				update_post_meta( intval($post_id), 'afwhp_hide_for_countries', '');
			}

			if ( isset( $_POST['afwhp_is_hide_price'] ) ) {
				update_post_meta( intval($post_id), 'afwhp_is_hide_price', esc_attr( sanitize_text_field($_POST['afwhp_is_hide_price']) ) );
			}

			if ( isset( $_POST['afwhp_hide_price_text'] ) ) {
				update_post_meta( intval($post_id), 'afwhp_hide_price_text', esc_attr( sanitize_text_field($_POST['afwhp_hide_price_text']) ) );
			}

			if ( isset( $_POST['afwhp_is_hide_addtocart'] ) ) {
				update_post_meta( intval($post_id), 'afwhp_is_hide_addtocart', esc_attr( sanitize_text_field($_POST['afwhp_is_hide_addtocart']) ) );
			}

			if ( isset( $_POST['afwhp_custom_button_text'] ) ) {
				update_post_meta( intval($post_id), 'afwhp_custom_button_text', esc_attr( sanitize_text_field($_POST['afwhp_custom_button_text']) ) );
			}

			if ( isset( $_POST['afwhp_custom_button_link'] ) ) {
				update_post_meta( intval($post_id), 'afwhp_custom_button_link', esc_attr( sanitize_text_field($_POST['afwhp_custom_button_link']) ) );
			}

			if ( isset( $_POST['afwhp_contact7_form'] ) ) {
				update_post_meta( intval($post_id), 'afwhp_contact7_form', esc_attr( sanitize_text_field($_POST['afwhp_contact7_form']) ) );
			}

		}

		public function afwhp_custom_columns( $columns) {

			unset($columns['date']);
			$columns['afwhp_rule_type'] = esc_html__( 'Rule Type', 'addify_whp' );
			$columns['date']            = esc_html__( 'Date Published', 'addify_whp' );

			return $columns;
		}

		public function afwhp_custom_column( $column, $post_id ) {
			$afwhp_post = get_post($post_id);
			switch ( $column ) {
				case 'afwhp_rule_type':
					$afwhp_rule_type = get_post_meta($post_id, 'afwhp_rule_type', true);
					if ('afwhp_for_registered_users' == $afwhp_rule_type) {
						echo esc_html__('Rule for Registered Users', 'addify_whp');
					} else {
						echo esc_html__('Rule for Guest Users', 'addify_whp');
					}
					break;
			}
		}

		public function afwhp_custom_menu_admin() {

			add_submenu_page( 'woocommerce', esc_html__( 'Hide Price', 'addify_whp' ), esc_html__( 'Hide Price', 'addify_whp' ), 'manage_options', 'edit.php?post_type=addify_whp', '' );

			
		}

		

		public function afwhpsearchProducts() {


			if ( !isset( $_POST['nonce'] ) || !wp_verify_nonce( sanitize_text_field($_POST['nonce']), 'afwhp-ajax-nonce' ) ) {
				die('Failed Ajax Security Check!');
			} 

			if (isset($_POST['q']) && '' != $_POST['q']) {
				

				$pro = sanitize_text_field( $_POST['q'] );

			} else {

				$pro = '';

			}


			$data_array = array();
			$args       = array(
				'post_type' => 'product',
				'post_status' => 'publish',
				'numberposts' => -1,
				's'	=>  $pro
			);
			$pros       = get_posts($args);

			if ( !empty($pros)) {

				foreach ($pros as $proo) {

					$title        = ( mb_strlen( $proo->post_title ) > 50 ) ? mb_substr( $proo->post_title, 0, 49 ) . '...' : $proo->post_title;
					$data_array[] = array( $proo->ID, $title ); // array( Post ID, Post Title )
				}
			}
			
			echo json_encode( $data_array );

			die();
		}
	}

	new Addify_Woo_Hide_Price_Admin();

}
