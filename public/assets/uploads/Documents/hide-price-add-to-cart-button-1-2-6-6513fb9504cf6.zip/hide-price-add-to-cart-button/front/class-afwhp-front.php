<?php

if ( ! defined( 'WPINC' ) ) {
	die;
}

if ( !class_exists( 'Addify_Woo_Hide_Price_Front' ) ) {

	class Addify_Woo_Hide_Price_Front extends Addify_Woo_Hide_Price {

		public function __construct() {

			add_action( 'wp_enqueue_scripts', array($this, 'afwhp_front_script'));
			add_filter( 'woocommerce_get_price_html', array($this, 'afwhp_remove_woocommerce_price_html'), 10, 2 );
			add_action( 'init', array($this, 'afwhp_custom_init' ));
			add_action( 'woocommerce_single_product_summary', array($this, 'afwhp_custom_product_button'), 1, 0 );

			add_filter('woocommerce_structured_data_product_offer', array($this, 'afwhp_remove_schema_price'), 10, 2);
		}

		public function afwhp_front_script() {

			wp_enqueue_style( 'afwhp-front', plugins_url( '../assets/css/afwhp_front.css', __FILE__ ), false, '1.0' );
			wp_enqueue_script('jquery');
			wp_enqueue_script( 'afwhp-frontj', plugins_url( '../assets/js/afwhp_front.js', __FILE__ ), false, '1.0' );
			wp_enqueue_script( 'afwhp-popup', plugins_url( '../assets/js/jquery.popupoverlay.js', __FILE__ ), false, '1.0' );
			
			
		}

		public function afwhp_custom_init() {

			//Replace add to cart button with custom button on shop page
			add_filter( 'woocommerce_loop_add_to_cart_link', array($this, 'afwhp_replace_loop_add_to_cart_link'), 10, 2 );
		}


		public function afwhp_remove_schema_price( $price, $product ) {
			global $user;
			

			$args = array(
				'post_type' => 'addify_whp',
				'post_status' => 'publish',
				'numberposts' => -1,
				'orderby' => 'menu_order',
				'order' => 'ASC'

			);
			$rules = get_posts($args);
			foreach ($rules as $rule) {

				$afwhp_rule_type          = get_post_meta( intval($rule->ID), 'afwhp_rule_type', true );
				$afwhp_rule_priority      = get_post_meta( intval($rule->ID), 'afwhp_rule_priority', true );
				$afwhp_hide_products      = unserialize(get_post_meta( intval($rule->ID), 'afwhp_hide_products', true ));
				$afwhp_hide_categories    = unserialize(get_post_meta( intval($rule->ID), 'afwhp_hide_categories', true ));
				$afwhp_hide_user_role     = unserialize(get_post_meta( intval($rule->ID), 'afwhp_hide_user_role', true ));
				$afwhp_is_hide_price      = get_post_meta( intval($rule->ID), 'afwhp_is_hide_price', true );
				$afwhp_hide_price_text    = get_post_meta( intval($rule->ID), 'afwhp_hide_price_text', true );
				$afwhp_is_hide_addtocart  = get_post_meta( intval($rule->ID), 'afwhp_is_hide_addtocart', true );
				$afwhp_custom_button_text = get_post_meta( intval($rule->ID), 'afwhp_custom_button_text', true );
				$afwhp_custom_button_link = get_post_meta( intval($rule->ID), 'afwhp_custom_button_link', true );
				$afwhp_contact7_form      = get_post_meta( intval($rule->ID), 'afwhp_contact7_form', true );

				$afwhp_hide_for_countries = unserialize(get_post_meta( intval($rule->ID), 'afwhp_hide_for_countries', true ));
				

				if (!empty($afwhp_hide_for_countries)) {
					//country
					if (!empty($_SERVER['REMOTE_ADDR'])) {
						$ip = sanitize_meta('', $_SERVER['REMOTE_ADDR'], '');
					} else {
						$ip = '';
					}
					$ch = curl_init();
					curl_setopt($ch, CURLOPT_URL, 'http://www.geoplugin.net/json.gp?ip=' . $ip);
					curl_setopt($ch, CURLOPT_HEADER, 0);
					curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
					$ip_data_in = curl_exec($ch); // string
					curl_close($ch);

					$ip_data = json_decode($ip_data_in, true);
					$ip_data = str_replace('&quot;', '"', $ip_data); // for PHP 5.2 see stackoverflow.com/questions/3110487/


					if ($ip_data && null != $ip_data['geoplugin_countryCode']) {
						$country = $ip_data['geoplugin_countryCode'];
					}


					$curr_country = $country;
				} else {

					$curr_country = '';

				}

				$istrue    = false;
				$iscountry = false;
				

				if (!empty($afwhp_hide_for_countries) && in_array($curr_country, $afwhp_hide_for_countries)) {

					$iscountry = true;

				} elseif (empty($afwhp_hide_for_countries)) {

					$iscountry = true;

				} else {

					$iscountry = false;
				}

				

				$applied_on_all_products = get_post_meta($rule->ID, 'afwhp_apply_on_all_products', true);

				if ('afwhp_for_registered_users' == $afwhp_rule_type ) {

					//Registered Users
					if ( is_user_logged_in() ) {

						// get Current User Role
						$curr_user      = wp_get_current_user();
						$user_data      = get_user_meta( $curr_user->ID );
						$curr_user_role = $curr_user->roles[0];

						if ( 'yes' == $applied_on_all_products && empty( $afwhp_hide_user_role ) ) {

							$istrue = true;

						} elseif (( is_array($afwhp_hide_user_role) && in_array($curr_user_role, $afwhp_hide_user_role) ) && 'yes' == $applied_on_all_products ) {

							$istrue = true;

						} elseif (( is_array($afwhp_hide_user_role) && in_array($curr_user_role, $afwhp_hide_user_role) ) && ( is_array($afwhp_hide_products) && in_array($product->get_id(), $afwhp_hide_products) )) {

							$istrue = true;


						}

						//Products
						
						if ( $istrue  && $iscountry) { 

							if ('yes' == $afwhp_is_hide_price) {

								if ( !empty($price[ 'price' ] ) ) {

									$price[ 'price' ] = '';
								}


								if ( !empty($price[ 'priceSpecification' ][ 'price']) ) {

									$price[ 'priceSpecification' ][ 'price'] = '';

								}
							}
						}

						//Categories
						if (!empty($afwhp_hide_categories ) && !$istrue  && $iscountry) {

							foreach ($afwhp_hide_categories as $cat) {

								if ( has_term( $cat , 'product_cat', $product->get_id() ) ) {
									
									
									if (in_array($curr_user_role, $afwhp_hide_user_role)) {

										if ('yes' == $afwhp_is_hide_price) {

											if ( !empty($price[ 'price' ] ) ) {

												$price[ 'price' ] = '';
											}


											if ( !empty($price[ 'priceSpecification' ][ 'price']) ) {

												$price[ 'priceSpecification' ][ 'price'] = '';

											}
										}
									}

									
								}

							}
						}
					}


				} else {

					//Guest Users
					//Products
					if ( !is_user_logged_in() ) {
						if ('yes' == $applied_on_all_products) {
							$istrue = true;
						} elseif (is_array($afwhp_hide_products) && in_array($product->get_id(), $afwhp_hide_products)) {
							$istrue = true;
						}

						if ( $istrue  && $iscountry) {

							if ('yes' == $afwhp_is_hide_price) {

								if ( !empty($price[ 'price' ] ) ) {

									$price[ 'price' ] = '';
								}


								if ( !empty($price[ 'priceSpecification' ][ 'price']) ) {

									$price[ 'priceSpecification' ][ 'price'] = '';

								}
							}
						}


						//Categories
						if (!empty($afwhp_hide_categories ) && !$istrue  && $iscountry) {

							foreach ($afwhp_hide_categories as $cat) {

								if ( has_term( $cat , 'product_cat', $product->get_id() ) ) {

									if ('yes' == $afwhp_is_hide_price) {

										if ( !empty($price[ 'price' ] ) ) {

											$price[ 'price' ] = '';
										}


										if ( !empty($price[ 'priceSpecification' ][ 'price']) ) {

											$price[ 'priceSpecification' ][ 'price'] = '';

										}


									}

								}

							}
						}
					}


				}


			}

			return $price;

		}



		public function afwhp_remove_woocommerce_price_html( $price, $product ) {
			global $user;
			$price_txt = $price;

			$args = array(
				'post_type' => 'addify_whp',
				'post_status' => 'publish',
				'numberposts' => -1,
				'orderby' => 'menu_order',
				'order' => 'ASC'

			);
			$rules = get_posts($args);
			foreach ($rules as $rule) {

				$afwhp_rule_type          = get_post_meta( intval($rule->ID), 'afwhp_rule_type', true );
				$afwhp_rule_priority      = get_post_meta( intval($rule->ID), 'afwhp_rule_priority', true );
				$afwhp_hide_products      = unserialize(get_post_meta( intval($rule->ID), 'afwhp_hide_products', true ));
				$afwhp_hide_categories    = unserialize(get_post_meta( intval($rule->ID), 'afwhp_hide_categories', true ));
				$afwhp_hide_user_role     = unserialize(get_post_meta( intval($rule->ID), 'afwhp_hide_user_role', true ));
				$afwhp_is_hide_price      = get_post_meta( intval($rule->ID), 'afwhp_is_hide_price', true );
				$afwhp_hide_price_text    = get_post_meta( intval($rule->ID), 'afwhp_hide_price_text', true );
				$afwhp_is_hide_addtocart  = get_post_meta( intval($rule->ID), 'afwhp_is_hide_addtocart', true );
				$afwhp_custom_button_text = get_post_meta( intval($rule->ID), 'afwhp_custom_button_text', true );
				$afwhp_custom_button_link = get_post_meta( intval($rule->ID), 'afwhp_custom_button_link', true );
				$afwhp_contact7_form      = get_post_meta( intval($rule->ID), 'afwhp_contact7_form', true );

				$afwhp_hide_for_countries = unserialize(get_post_meta( intval($rule->ID), 'afwhp_hide_for_countries', true ));
				

				if (!empty($afwhp_hide_for_countries)) {
					//country
					if (!empty($_SERVER['REMOTE_ADDR'])) {
						$ip = sanitize_meta('', $_SERVER['REMOTE_ADDR'], '');
					} else {
						$ip = '';
					}
					$ch = curl_init();
					curl_setopt($ch, CURLOPT_URL, 'http://www.geoplugin.net/json.gp?ip=' . $ip);
					curl_setopt($ch, CURLOPT_HEADER, 0);
					curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
					$ip_data_in = curl_exec($ch); // string
					curl_close($ch);

					$ip_data = json_decode($ip_data_in, true);
					$ip_data = str_replace('&quot;', '"', $ip_data); // for PHP 5.2 see stackoverflow.com/questions/3110487/


					if ($ip_data && null != $ip_data['geoplugin_countryCode']) {
						$country = $ip_data['geoplugin_countryCode'];
					}


					$curr_country = $country;
				} else {

					$curr_country = '';

				}

				$istrue    = false;
				$iscountry = false;
				

				if (!empty($afwhp_hide_for_countries) && in_array($curr_country, $afwhp_hide_for_countries)) {

					$iscountry = true;

				} elseif (empty($afwhp_hide_for_countries)) {

					$iscountry = true;

				} else {

					$iscountry = false;
				}

				

				$applied_on_all_products = get_post_meta($rule->ID, 'afwhp_apply_on_all_products', true);

				if ('afwhp_for_registered_users' == $afwhp_rule_type ) {

					//Registered Users
					if ( is_user_logged_in() ) {

						// get Current User Role
						$curr_user      = wp_get_current_user();
						$user_data      = get_user_meta( $curr_user->ID );
						$curr_user_role = $curr_user->roles[0];

						if ( 'yes' == $applied_on_all_products && empty( $afwhp_hide_user_role ) ) {

							$istrue = true;

						} elseif (( is_array($afwhp_hide_user_role) && in_array($curr_user_role, $afwhp_hide_user_role) ) && 'yes' == $applied_on_all_products ) {

							$istrue = true;

						} elseif (( is_array($afwhp_hide_user_role) && in_array($curr_user_role, $afwhp_hide_user_role) ) && ( is_array($afwhp_hide_products) && in_array($product->get_id(), $afwhp_hide_products) )) {

							$istrue = true;


						}

						//Products
						
						if ( $istrue  && $iscountry) { 

							if ('yes' == $afwhp_is_hide_price) {

								$price_txt = $afwhp_hide_price_text;
								?>
								<style>
									.woocommerce-variation-price{ display: none !important;}
								</style>
								<?php
							}
						}

						//Categories
						if (!empty($afwhp_hide_categories ) && !$istrue  && $iscountry) {

							foreach ($afwhp_hide_categories as $cat) {

								if ( has_term( $cat , 'product_cat', $product->get_id() ) ) {
									
									
									if (in_array($curr_user_role, $afwhp_hide_user_role)) {

										if ('yes' == $afwhp_is_hide_price) {

											$price_txt = $afwhp_hide_price_text;
											?>
											<style>
												.woocommerce-variation-price{ display: none !important;}
											</style>
											<?php
										}
									}

									
								}

							}
						}
					}


				} else {

					//Guest Users
					//Products
					if ( !is_user_logged_in() ) {
						if ('yes' == $applied_on_all_products) {
							$istrue = true;
						} elseif (is_array($afwhp_hide_products) && in_array($product->get_id(), $afwhp_hide_products)) {
							$istrue = true;
						}

						if ( $istrue  && $iscountry) {

							if ('yes' == $afwhp_is_hide_price) {

								$price_txt = $afwhp_hide_price_text;
								?>
								<style>
									.woocommerce-variation-price{ display: none !important;}
								</style>
								<?php
							}
						}


						//Categories
						if (!empty($afwhp_hide_categories ) && !$istrue  && $iscountry) {

							foreach ($afwhp_hide_categories as $cat) {

								if ( has_term( $cat , 'product_cat', $product->get_id() ) ) {

									if ('yes' == $afwhp_is_hide_price) {

										$price_txt = $afwhp_hide_price_text;
										?>
										<style>
											.woocommerce-variation-price{ display: none !important;}
										</style>
										<?php
									}

								}

							}
						}
					}


				}


			}

			return $price_txt;

		}


		public function afwhp_replace_loop_add_to_cart_link( $html, $product) {

			$pageurl = get_page_link(get_option('addify_atq_page_id', true));
			global $user;
			$cart_txt = $html;

			$args = array(
				'post_type' => 'addify_whp',
				'post_status' => 'publish',
				'numberposts' => -1,
				'orderby' => 'menu_order',
				'order' => 'ASC'

			);
			$rules = get_posts($args);
			foreach ($rules as $rule) {

				$afwhp_rule_type          = get_post_meta( intval($rule->ID), 'afwhp_rule_type', true );
				$afwhp_rule_priority      = get_post_meta( intval($rule->ID), 'afwhp_rule_priority', true );
				$afwhp_hide_products      = unserialize(get_post_meta( intval($rule->ID), 'afwhp_hide_products', true ));
				$afwhp_hide_categories    = unserialize(get_post_meta( intval($rule->ID), 'afwhp_hide_categories', true ));
				$afwhp_hide_user_role     = unserialize(get_post_meta( intval($rule->ID), 'afwhp_hide_user_role', true ));
				$afwhp_is_hide_price      = get_post_meta( intval($rule->ID), 'afwhp_is_hide_price', true );
				$afwhp_hide_price_text    = get_post_meta( intval($rule->ID), 'afwhp_hide_price_text', true );
				$afwhp_is_hide_addtocart  = get_post_meta( intval($rule->ID), 'afwhp_is_hide_addtocart', true );
				$afwhp_custom_button_text = get_post_meta( intval($rule->ID), 'afwhp_custom_button_text', true );
				
				$afwhp_custom_button_link = get_post_meta( intval($rule->ID), 'afwhp_custom_button_link', true );
				
				$afwhp_contact7_form      = get_post_meta( intval($rule->ID), 'afwhp_contact7_form', true );
				$afwhp_hide_for_countries = unserialize(get_post_meta( intval($rule->ID), 'afwhp_hide_for_countries', true ));

				if (!empty($afwhp_hide_for_countries)) {
					//country
					if (!empty($_SERVER['REMOTE_ADDR'])) {
						$ip = sanitize_meta('', $_SERVER['REMOTE_ADDR'], '');
					} else {
						$ip = '';
					}
					$ch = curl_init();
					curl_setopt($ch, CURLOPT_URL, 'http://www.geoplugin.net/json.gp?ip=' . $ip);
					curl_setopt($ch, CURLOPT_HEADER, 0);
					curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
					$ip_data_in = curl_exec($ch); // string
					curl_close($ch);

					$ip_data = json_decode($ip_data_in, true);
					$ip_data = str_replace('&quot;', '"', $ip_data); // for PHP 5.2 see stackoverflow.com/questions/3110487/


					if ($ip_data && null != $ip_data['geoplugin_countryCode']) {
						$country = $ip_data['geoplugin_countryCode'];
					}


					$curr_country = $country;
				} else {

					$curr_country = '';

				}

				$istrue    = false;
				$iscountry = false;

				if (!empty($afwhp_hide_for_countries) && in_array($curr_country, $afwhp_hide_for_countries)) {

					$iscountry = true;

				} elseif (empty($afwhp_hide_for_countries)) {

					$iscountry = true;

				} else {

					$iscountry = false;
				}

				$applied_on_all_products = get_post_meta($rule->ID, 'afwhp_apply_on_all_products', true);


				if ('variable' != $product->get_type() ) {

					if ('afwhp_for_registered_users' == $afwhp_rule_type) {
						//Registered Users

						if ( is_user_logged_in() ) {


							// get Current User Role
							$curr_user      = wp_get_current_user();
							$user_data      = get_user_meta( $curr_user->ID );
							$curr_user_role = $curr_user->roles[0];

							if ( 'yes' == $applied_on_all_products && empty( $afwhp_hide_user_role ) ) {
								$istrue = true;
							} elseif (( is_array($afwhp_hide_user_role) && in_array($curr_user_role, $afwhp_hide_user_role) ) && 'yes' == $applied_on_all_products ) {
								$istrue = true;
							} elseif (( is_array($afwhp_hide_user_role) && in_array($curr_user_role, $afwhp_hide_user_role) ) && ( is_array($afwhp_hide_products) && in_array($product->get_id(), $afwhp_hide_products) )) {
								$istrue = true;
							}
							//Products
							if ( $istrue && $iscountry) {

								if ( $this->check_required_addons( $product->get_id() ) ) {
									//WooCommerce Product Addons compatibility

									return $html;

								} else {

									if ( 'yes' == $afwhp_is_hide_addtocart) {

										if ( '' == $afwhp_custom_button_text) {

											$cart_txt = '';
										} else {

											if (!empty($afwhp_custom_button_link)) {

												$cart_txt = '<a href="' . esc_url( $afwhp_custom_button_link ) . '" rel="nofollow" class="button add_to_cart_button product_type_' . $product->get_type() . '">' . esc_attr($afwhp_custom_button_text) . '</a>';
											} elseif (!empty($afwhp_contact7_form)) {

												$contact7_cart_txt = '<a href="#form_popup' . $afwhp_contact7_form . $product->get_id() . '" class="form_popup' . $afwhp_contact7_form . $product->get_id() . '_open button product_type_simple add_to_cart_button">' . esc_attr($afwhp_custom_button_text) . '</a>';

												$contact7 = get_post($afwhp_contact7_form);


												$form_title = $contact7->post_title;

												$popup  = '<div id="form_popup' . $afwhp_contact7_form . $product->get_id() . '" class="form_popup">';
												$popup .= '<button class="form_popup' . $afwhp_contact7_form . $product->get_id() . '_close form_close_btn btn btn-default">X</button>';
												
												$popup .= do_shortcode('[contact-form-7 id="' . $afwhp_contact7_form . '" title="' . $form_title . '" ] ');
												
												$popup .= '</div>';

												$popup .= '<script type="text/javascript">';
												$popup .= '	jQuery(document).ready(function() {';
												$popup .= '		jQuery("#form_popup' . $afwhp_contact7_form . $product->get_id() . '").popup();';
												$popup .= '	});';
												$popup .= '</script>';

												$cart_txt = $contact7_cart_txt . $popup;

											} else {

												$cart_txt = '<a href="javascript:void(0)" rel="nofollow" class="button add_to_cart_button product_type_' . $product->get_type() . '">' . esc_attr($afwhp_custom_button_text) . '</a>';
											}
											
										} 
									}

									

								}
							}


							//Categories
							if (!empty($afwhp_hide_categories ) && !$istrue && $iscountry) {

								foreach ($afwhp_hide_categories as $cat) {

									if ( has_term( $cat , 'product_cat', $product->get_id() ) ) {
										
										
										if (in_array($curr_user_role, $afwhp_hide_user_role)) {

											
											if ( $this->check_required_addons( $product->get_id() ) ) {
												//WooCommerce Product Addons compatibility

												return $html;

											} else {

												if ( 'yes' == $afwhp_is_hide_addtocart) {

													if ( '' == $afwhp_custom_button_text) {

														$cart_txt = '';
														return $cart_txt;
													} else {

														if (!empty($afwhp_custom_button_link)) {

															$cart_txt = '<a href="' . esc_url( $afwhp_custom_button_link ) . '" rel="nofollow" class="button add_to_cart_button product_type_' . $product->get_type() . '">' . esc_attr($afwhp_custom_button_text) . '</a>';
															return $cart_txt;
														} elseif (!empty($afwhp_contact7_form)) {

															$contact7_cart_txt = '<a href="#form_popup' . $afwhp_contact7_form . $product->get_id() . '" class="form_popup' . $afwhp_contact7_form . $product->get_id() . '_open button product_type_simple add_to_cart_button">' . esc_attr($afwhp_custom_button_text) . '</a>';

															$contact7 = get_post($afwhp_contact7_form);


															$form_title = $contact7->post_title;

															$popup  = '<div id="form_popup' . $afwhp_contact7_form . $product->get_id() . '" class="form_popup">';
															$popup .= '<button class="form_popup' . $afwhp_contact7_form . $product->get_id() . '_close form_close_btn btn btn-default">X</button>';
														
															$popup .= do_shortcode('[contact-form-7 id="' . $afwhp_contact7_form . '" title="' . $form_title . '" ] ');
														
															$popup .= '</div>';

															$popup .= '<script type="text/javascript">';
															$popup .= '	jQuery(document).ready(function() {';
															$popup .= '		jQuery("#form_popup' . $afwhp_contact7_form . $product->get_id() . '").popup();';
															$popup .= '	});';
															$popup .= '</script>';

															$cart_txt = $contact7_cart_txt . $popup;

															return $cart_txt;
														} else {

															$cart_txt = '<a href="javascript:void(0)" rel="nofollow" class="button add_to_cart_button product_type_' . $product->get_type() . '">' . esc_attr($afwhp_custom_button_text) . '</a>';
															return $cart_txt;

														}
													
													} 
												}

											}

										}

										
									}

								}
							}

						}


					} else {
						//Guest Users

						if ( !is_user_logged_in() ) {

							//Products
							if ('yes' == $applied_on_all_products) {
								$istrue = true;
							} elseif (is_array($afwhp_hide_products) && in_array($product->get_id(), $afwhp_hide_products)) {
								$istrue = true;
							}

							if ( $istrue && $iscountry) {

								
								if ( $this->check_required_addons( $product->get_id() ) ) {
									//WooCommerce Product Addons compatibility

									return $html;

								} else {

									if ( 'yes' == $afwhp_is_hide_addtocart) {

										if ( '' == $afwhp_custom_button_text) {

											$cart_txt = '';
										} else {

											if (!empty($afwhp_custom_button_link)) {

												$cart_txt = '<a href="' . esc_url( $afwhp_custom_button_link ) . '" rel="nofollow" class="button add_to_cart_button product_type_' . $product->get_type() . '">' . esc_attr($afwhp_custom_button_text) . '</a>';
											} elseif (!empty($afwhp_contact7_form)) {

												$contact7_cart_txt = '<a href="#form_popup' . $afwhp_contact7_form . $product->get_id() . '" class="form_popup' . $afwhp_contact7_form . $product->get_id() . '_open button product_type_simple add_to_cart_button">' . esc_attr($afwhp_custom_button_text) . '</a>';

												$contact7 = get_post($afwhp_contact7_form);


												$form_title = $contact7->post_title;

												$popup  = '<div id="form_popup' . $afwhp_contact7_form . $product->get_id() . '" class="form_popup">';
												$popup .= '<button class="form_popup' . $afwhp_contact7_form . $product->get_id() . '_close form_close_btn btn btn-default">X</button>';
												
												$popup .= do_shortcode('[contact-form-7 id="' . $afwhp_contact7_form . '" title="' . $form_title . '" ] ');
												
												$popup .= '</div>';

												$popup .= '<script type="text/javascript">';
												$popup .= '	jQuery(document).ready(function() {';
												$popup .= '		jQuery("#form_popup' . $afwhp_contact7_form . $product->get_id() . '").popup();';
												$popup .= '	});';
												$popup .= '</script>';

												$cart_txt = $contact7_cart_txt . $popup;


											} else {

												$cart_txt = '<a href="javascript:void(0)" rel="nofollow" class="button add_to_cart_button product_type_' . $product->get_type() . '">' . esc_attr($afwhp_custom_button_text) . '</a>';
											}
											
										} 
									}

								}

							}


							//Categories
							if (!empty($afwhp_hide_categories ) && !$istrue && $iscountry) {

								foreach ($afwhp_hide_categories as $cat) {

									if ( has_term( $cat , 'product_cat', $product->get_id() ) ) {

										if ( $this->check_required_addons( $product->get_id() ) ) {
											//WooCommerce Product Addons compatibility

											return $html;

										} else {

											if ( 'yes' == $afwhp_is_hide_addtocart) {

												if ( '' == $afwhp_custom_button_text) {

													$cart_txt = '';
												} else {

													if (!empty($afwhp_custom_button_link)) {

														$cart_txt = '<a href="' . esc_url( $afwhp_custom_button_link ) . '" rel="nofollow" class="button add_to_cart_button product_type_' . $product->get_type() . '">' . esc_attr($afwhp_custom_button_text) . '</a>';
														return $cart_txt;
													} elseif (!empty($afwhp_contact7_form)) {

														$contact7_cart_txt = '<a href="#form_popup' . $afwhp_contact7_form . $product->get_id() . '" class="form_popup' . $afwhp_contact7_form . $product->get_id() . '_open button product_type_simple add_to_cart_button">' . esc_attr($afwhp_custom_button_text) . '</a>';

														$contact7 = get_post($afwhp_contact7_form);


														$form_title = $contact7->post_title;

														$popup  = '<div id="form_popup' . $afwhp_contact7_form . $product->get_id() . '" class="form_popup">';
														$popup .= '<button class="form_popup' . $afwhp_contact7_form . $product->get_id() . '_close form_close_btn btn btn-default">X</button>';
														
														$popup .= do_shortcode('[contact-form-7 id="' . $afwhp_contact7_form . '" title="' . $form_title . '" ] ');
														
														$popup .= '</div>';

														$popup .= '<script type="text/javascript">';
														$popup .= '	jQuery(document).ready(function() {';
														$popup .= '		jQuery("#form_popup' . $afwhp_contact7_form . $product->get_id() . '").popup();';
														$popup .= '	});';
														$popup .= '</script>';

														$cart_txt = $contact7_cart_txt . $popup;
														return $cart_txt;
													} else {

														$cart_txt = '<a href="javascript:void(0)" rel="nofollow" class="button add_to_cart_button product_type_' . $product->get_type() . '">' . esc_attr($afwhp_custom_button_text) . '</a>';
														return $cart_txt;
													}
													
												} 
											}

										}

									}

								}
							}


						}


					}
					
				}

			}

			return $cart_txt;

		}


		public function afwhp_custom_product_button() {

			global $user, $product;

			$args = array(
				'post_type' => 'addify_whp',
				'post_status' => 'publish',
				'numberposts' => -1,
				'orderby' => 'menu_order',
				'order' => 'ASC'

			);
			$rules = get_posts($args);
			foreach ($rules as $rule) {

				$afwhp_rule_type          = get_post_meta( intval($rule->ID), 'afwhp_rule_type', true );
				$afwhp_rule_priority      = get_post_meta( intval($rule->ID), 'afwhp_rule_priority', true );
				$afwhp_hide_products      = unserialize(get_post_meta( intval($rule->ID), 'afwhp_hide_products', true ));
				$afwhp_hide_categories    = unserialize(get_post_meta( intval($rule->ID), 'afwhp_hide_categories', true ));
				$afwhp_hide_user_role     = unserialize(get_post_meta( intval($rule->ID), 'afwhp_hide_user_role', true ));
				$afwhp_is_hide_price      = get_post_meta( intval($rule->ID), 'afwhp_is_hide_price', true );
				$afwhp_hide_price_text    = get_post_meta( intval($rule->ID), 'afwhp_hide_price_text', true );
				$afwhp_is_hide_addtocart  = get_post_meta( intval($rule->ID), 'afwhp_is_hide_addtocart', true );
				$afwhp_custom_button_text = get_post_meta( intval($rule->ID), 'afwhp_custom_button_text', true );
				
				$afwhp_custom_button_link = get_post_meta( intval($rule->ID), 'afwhp_custom_button_link', true );
				
				$afwhp_contact7_form      = get_post_meta( intval($rule->ID), 'afwhp_contact7_form', true );
				$afwhp_hide_for_countries = unserialize(get_post_meta( intval($rule->ID), 'afwhp_hide_for_countries', true ));

				if (!empty($afwhp_hide_for_countries)) {
					//country
					if (!empty($_SERVER['REMOTE_ADDR'])) {
						$ip = sanitize_meta('', $_SERVER['REMOTE_ADDR'], '');
					} else {
						$ip = '';
					}
					$ch = curl_init();
					curl_setopt($ch, CURLOPT_URL, 'http://www.geoplugin.net/json.gp?ip=' . $ip);
					curl_setopt($ch, CURLOPT_HEADER, 0);
					curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
					$ip_data_in = curl_exec($ch); // string
					curl_close($ch);

					$ip_data = json_decode($ip_data_in, true);
					$ip_data = str_replace('&quot;', '"', $ip_data); // for PHP 5.2 see stackoverflow.com/questions/3110487/


					if ($ip_data && null != $ip_data['geoplugin_countryCode']) {
						$country = $ip_data['geoplugin_countryCode'];
					}


					$curr_country = $country;
				} else {

					$curr_country = '';

				}

				$istrue = false;

				$iscountry = false;

				if (!empty($afwhp_hide_for_countries) && in_array($curr_country, $afwhp_hide_for_countries)) {

					$iscountry = true;

				} elseif (empty($afwhp_hide_for_countries)) {

					$iscountry = true;

				} else {

					$iscountry = false;
				}

				$applied_on_all_products = get_post_meta($rule->ID, 'afwhp_apply_on_all_products', true);

				//Registered Users
				if ('afwhp_for_registered_users' == $afwhp_rule_type) {

					if ( is_user_logged_in() ) {

						// get Current User Role
						$curr_user      = wp_get_current_user();
						$user_data      = get_user_meta( $curr_user->ID );
						$curr_user_role = $curr_user->roles[0];

						if ( 'yes' == $applied_on_all_products && empty( $afwhp_hide_user_role ) ) {
							$istrue = true;
						} elseif (( is_array($afwhp_hide_user_role) && in_array($curr_user_role, $afwhp_hide_user_role) ) && 'yes' == $applied_on_all_products ) {
							$istrue = true;
						} elseif (( is_array($afwhp_hide_user_role) && in_array($curr_user_role, $afwhp_hide_user_role) ) && ( is_array($afwhp_hide_products) && in_array($product->get_id(), $afwhp_hide_products) )) {
							$istrue = true;
						}

						//Products
						if ( $istrue && $iscountry) {
							if ('yes' == $afwhp_is_hide_addtocart) {

								if ('variable' == $product->get_type()) {

									remove_action( 'woocommerce_single_variation', 'woocommerce_single_variation_add_to_cart_button', 20 );
									add_action( 'woocommerce_single_variation', array($this, 'afwhp_custom_button_replacement'), 30 );

								} else {

									remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 30 );
									add_action( 'woocommerce_single_product_summary', array($this, 'afwhp_custom_button_replacement'), 30 );
								}
							}

						}

						//Categories

						if (!empty($afwhp_hide_categories ) && !$istrue && $iscountry) {

							foreach ($afwhp_hide_categories as $cat) {

								if ( has_term( $cat , 'product_cat', $product->get_id() ) ) {
									
									
									if (in_array($curr_user_role, $afwhp_hide_user_role)) {

										
										if ('yes' == $afwhp_is_hide_addtocart) {

											if ('variable' == $product->get_type()) {

												remove_action( 'woocommerce_single_variation', 'woocommerce_single_variation_add_to_cart_button', 20 );
												add_action( 'woocommerce_single_variation', array($this, 'afwhp_custom_button_replacement'), 30 );

											} else {

												remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 30 );
												add_action( 'woocommerce_single_product_summary', array($this, 'afwhp_custom_button_replacement'), 30 );
											}
										}

									}

									
								}

							}
						}


					}


				} else {
					//Guest Users

					if ( !is_user_logged_in() ) {

						//Products
						if ('yes' == $applied_on_all_products) {
							$istrue = true;
						} elseif (is_array($afwhp_hide_products) && in_array($product->get_id(), $afwhp_hide_products)) {
							$istrue = true;
						}

						if ( $istrue && $iscountry) {

							
							if ('yes' == $afwhp_is_hide_addtocart) {

								if ( 'variable' == $product->get_type()) {

									remove_action( 'woocommerce_single_variation', 'woocommerce_single_variation_add_to_cart_button', 20 );
									add_action( 'woocommerce_single_variation', array($this, 'afwhp_custom_button_replacement'), 30 );

								} else {

									remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 30 );
									add_action( 'woocommerce_single_product_summary', array($this, 'afwhp_custom_button_replacement'), 30 );
								}
							}

						}


						//Categories
						if (!empty($afwhp_hide_categories ) && !$istrue && $iscountry) {

							foreach ($afwhp_hide_categories as $cat) {

								if ( has_term( $cat , 'product_cat', $product->get_id() ) ) {

									if ('yes' == $afwhp_is_hide_addtocart) {

										if ( 'variable' == $product->get_type()) {

											remove_action( 'woocommerce_single_variation', 'woocommerce_single_variation_add_to_cart_button', 20 );
											add_action( 'woocommerce_single_variation', array($this, 'afwhp_custom_button_replacement'), 30 );

										} else {

											remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 30 );
											add_action( 'woocommerce_single_product_summary', array($this, 'afwhp_custom_button_replacement'), 30 );
										}
									}

								}

							}
						}


					}

				}


				

			}


		}



		public function afwhp_custom_button_replacement() {

			$pageurl = get_page_link(get_option('addify_atq_page_id', true));

			global $user, $product;

			$args = array(
				'post_type' => 'addify_whp',
				'post_status' => 'publish',
				'numberposts' => -1,
				'orderby' => 'menu_order',
				'order' => 'ASC'

			);
			$rules = get_posts($args);
			foreach ($rules as $rule) {

				$afwhp_rule_type          = get_post_meta( intval($rule->ID), 'afwhp_rule_type', true );
				$afwhp_rule_priority      = get_post_meta( intval($rule->ID), 'afwhp_rule_priority', true );
				$afwhp_hide_products      = unserialize(get_post_meta( intval($rule->ID), 'afwhp_hide_products', true ));
				$afwhp_hide_categories    = unserialize(get_post_meta( intval($rule->ID), 'afwhp_hide_categories', true ));
				$afwhp_hide_user_role     = unserialize(get_post_meta( intval($rule->ID), 'afwhp_hide_user_role', true ));
				$afwhp_is_hide_price      = get_post_meta( intval($rule->ID), 'afwhp_is_hide_price', true );
				$afwhp_hide_price_text    = get_post_meta( intval($rule->ID), 'afwhp_hide_price_text', true );
				$afwhp_is_hide_addtocart  = get_post_meta( intval($rule->ID), 'afwhp_is_hide_addtocart', true );
				$afwhp_custom_button_text = get_post_meta( intval($rule->ID), 'afwhp_custom_button_text', true );
				
				$afwhp_custom_button_link = get_post_meta( intval($rule->ID), 'afwhp_custom_button_link', true );
				
				$afwhp_contact7_form      = get_post_meta( intval($rule->ID), 'afwhp_contact7_form', true );
				$afwhp_hide_for_countries = unserialize(get_post_meta( intval($rule->ID), 'afwhp_hide_for_countries', true ));

				if (!empty($afwhp_hide_for_countries)) {
					//country
					if (!empty($_SERVER['REMOTE_ADDR'])) {
						$ip = sanitize_meta('', $_SERVER['REMOTE_ADDR'], '');
					} else {
						$ip = '';
					}
					$ch = curl_init();
					curl_setopt($ch, CURLOPT_URL, 'http://www.geoplugin.net/json.gp?ip=' . $ip);
					curl_setopt($ch, CURLOPT_HEADER, 0);
					curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
					$ip_data_in = curl_exec($ch); // string
					curl_close($ch);

					$ip_data = json_decode($ip_data_in, true);
					$ip_data = str_replace('&quot;', '"', $ip_data); // for PHP 5.2 see stackoverflow.com/questions/3110487/


					if ($ip_data && null != $ip_data['geoplugin_countryCode']) {
						$country = $ip_data['geoplugin_countryCode'];
					}


					$curr_country = $country;
				} else {

					$curr_country = '';

				}

				$istrue = false;

				$iscountry = false;

				if (!empty($afwhp_hide_for_countries) && in_array($curr_country, $afwhp_hide_for_countries)) {

					$iscountry = true;

				} elseif (empty($afwhp_hide_for_countries)) {

					$iscountry = true;

				} else {

					$iscountry = false;
				}

				$applied_on_all_products = get_post_meta($rule->ID, 'afwhp_apply_on_all_products', true);

				
				//Registered Users
				if ('afwhp_for_registered_users' == $afwhp_rule_type) {

					if ( is_user_logged_in() ) {

						// get Current User Role
						$curr_user      = wp_get_current_user();
						$user_data      = get_user_meta( $curr_user->ID );
						$curr_user_role = $curr_user->roles[0];

						if ( 'yes' == $applied_on_all_products && empty( $afwhp_hide_user_role ) ) {
							$istrue = true;
						} elseif (( is_array($afwhp_hide_user_role) && in_array($curr_user_role, $afwhp_hide_user_role) ) && 'yes' == $applied_on_all_products ) {
							$istrue = true;
						} elseif (( is_array($afwhp_hide_user_role) && in_array($curr_user_role, $afwhp_hide_user_role) ) && ( is_array($afwhp_hide_products) && in_array($product->get_id(), $afwhp_hide_products) )) {
							$istrue = true;
						}


						//Products
						if ( $istrue && $iscountry) {
							
							if ( 'yes' == $afwhp_is_hide_addtocart) {

								if ( '' == $afwhp_custom_button_text) {

									echo '';
								} else {

									if (!empty($afwhp_custom_button_link)) {

										echo '<a href="' . esc_url( $afwhp_custom_button_link ) . '" rel="nofollow" class="button add_to_cart_button product_type_' . esc_attr($product->get_type()) . '">' . esc_attr($afwhp_custom_button_text) . '</a>';
									} elseif (!empty($afwhp_contact7_form)) {

										$contact7 = get_post($afwhp_contact7_form);


										$form_title = $contact7->post_title;

										?>
										<a href="javascript:void(0)" onclick="showPopForm('<?php echo esc_attr($afwhp_contact7_form) . esc_attr($product->get_id()); ?>')" class="form_popup<?php echo esc_attr($afwhp_contact7_form) . esc_attr($product->get_id()); ?>_open button product_type_simple add_to_cart_button"><?php echo esc_attr($afwhp_custom_button_text); ?></a>
										<div id="form_popup<?php echo esc_attr($afwhp_contact7_form) . esc_attr($product->get_id()); ?>" class="form_popup">
											
											<button class="form_popup<?php echo esc_attr($afwhp_contact7_form) . esc_attr($product->get_id()); ?>_close form_close_btn btn btn-default">X</button>

											<?php echo do_shortcode('[contact-form-7 id="' . $afwhp_contact7_form . '" title="' . $form_title . '" ] '); ?>

										</div>

										<?php

									} else {

										echo '<a href="javascript:void(0)" rel="nofollow" class="button add_to_cart_button product_type_' . esc_attr($product->get_type()) . '">' . esc_attr($afwhp_custom_button_text) . '</a>';
									}
									
								} 
							}

						}


						//Categories

						if (!empty($afwhp_hide_categories ) && !$istrue && $iscountry) {

							foreach ($afwhp_hide_categories as $cat) {

								if ( has_term( $cat , 'product_cat', $product->get_id() ) ) {
									
									
									if (in_array($curr_user_role, $afwhp_hide_user_role)) {

										
										if ( 'yes' == $afwhp_is_hide_addtocart) {

											if ( '' == $afwhp_custom_button_text) {

												echo '';
											} else {

												if (!empty($afwhp_custom_button_link)) {

													echo '<a href="' . esc_url( $afwhp_custom_button_link ) . '" rel="nofollow" class="button add_to_cart_button product_type_' . esc_attr($product->get_type()) . '">' . esc_attr($afwhp_custom_button_text) . '</a>';
													return;
												} elseif (!empty($afwhp_contact7_form)) {

													$contact7 = get_post($afwhp_contact7_form);


													$form_title = $contact7->post_title;

													?>
													<a href="javascript:void(0)" onclick="showPopForm('<?php echo esc_attr($afwhp_contact7_form) . esc_attr($product->get_id()); ?>')" class="form_popup<?php echo esc_attr($afwhp_contact7_form) . esc_attr($product->get_id()); ?>_open button product_type_simple add_to_cart_button"><?php echo esc_attr($afwhp_custom_button_text); ?></a>
													<div id="form_popup<?php echo esc_attr($afwhp_contact7_form) . esc_attr($product->get_id()); ?>" class="form_popup">
														
														<button class="form_popup<?php echo esc_attr($afwhp_contact7_form) . esc_attr($product->get_id()); ?>_close form_close_btn btn btn-default">X</button>

														<?php echo do_shortcode('[contact-form-7 id="' . $afwhp_contact7_form . '" title="' . $form_title . '" ] '); ?>

													</div>

													<?php
													return;
												} else {

													echo '<a href="javascript:void(0)" rel="nofollow" class="button add_to_cart_button product_type_' . esc_attr($product->get_type()) . '">' . esc_attr($afwhp_custom_button_text) . '</a>';
													return;
												}
												
											} 
										}

									}

									
								}

							}
						}




					}

				} else {
					//Guest Users
					if ( !is_user_logged_in() ) {

						//Products
						if ('yes' == $applied_on_all_products) {
							$istrue = true;
						} elseif (is_array($afwhp_hide_products) && in_array($product->get_id(), $afwhp_hide_products)) {
							$istrue = true;
						}

						if ( $istrue && $iscountry) {

							
							if ( 'yes' == $afwhp_is_hide_addtocart) {

								if ( '' == $afwhp_custom_button_text) {

									echo '';
								} else {

									if (!empty($afwhp_custom_button_link)) {

										echo '<a href="' . esc_url( $afwhp_custom_button_link ) . '" rel="nofollow" class="button add_to_cart_button product_type_' . esc_attr($product->get_type()) . '">' . esc_attr($afwhp_custom_button_text) . '</a>';
									} elseif (!empty($afwhp_contact7_form)) {

										$contact7 = get_post($afwhp_contact7_form);


										$form_title = $contact7->post_title;

										?>
										<a href="javascript:void(0)" onclick="showPopForm('<?php echo esc_attr($afwhp_contact7_form) . esc_attr($product->get_id()); ?>')" class="form_popup<?php echo esc_attr($afwhp_contact7_form) . esc_attr($product->get_id()); ?>_open button product_type_simple add_to_cart_button"><?php echo esc_attr($afwhp_custom_button_text); ?></a>
										<div id="form_popup<?php echo esc_attr($afwhp_contact7_form) . esc_attr($product->get_id()); ?>" class="form_popup">
											
											<button class="form_popup<?php echo esc_attr($afwhp_contact7_form) . esc_attr($product->get_id()); ?>_close form_close_btn btn btn-default">X</button>

											<?php echo do_shortcode('[contact-form-7 id="' . $afwhp_contact7_form . '" title="' . $form_title . '" ] '); ?>

										</div>

										<?php

									} else {

										echo '<a href="javascript:void(0)" rel="nofollow" class="button add_to_cart_button product_type_' . esc_attr($product->get_type()) . '">' . esc_attr($afwhp_custom_button_text) . '</a>';
									}
									
								} 
							}

						}
						

						//Categories
						if (!empty($afwhp_hide_categories ) && !$istrue && $iscountry) {

							foreach ($afwhp_hide_categories as $cat) {

								if ( has_term( $cat , 'product_cat', $product->get_id() ) ) {

									if ( 'yes' == $afwhp_is_hide_addtocart) {

										if ( '' == $afwhp_custom_button_text) {

											echo '';
										} else {

											if (!empty($afwhp_custom_button_link)) {

												echo '<a href="' . esc_url( $afwhp_custom_button_link ) . '" rel="nofollow" class="button add_to_cart_button product_type_' . esc_attr($product->get_type()) . '">' . esc_attr($afwhp_custom_button_text) . '</a>';
												return;
											} elseif (!empty($afwhp_contact7_form)) {

												$contact7 = get_post($afwhp_contact7_form);


												$form_title = $contact7->post_title;

												?>
												<a href="javascript:void(0)" onclick="showPopForm('<?php echo esc_attr($afwhp_contact7_form) . esc_attr($product->get_id()); ?>')" class="form_popup<?php echo esc_attr($afwhp_contact7_form) . esc_attr($product->get_id()); ?>_open button product_type_simple add_to_cart_button"><?php echo esc_attr($afwhp_custom_button_text); ?></a>
												<div id="form_popup<?php echo esc_attr($afwhp_contact7_form) . esc_attr($product->get_id()); ?>" class="form_popup">
													
													<button class="form_popup<?php echo esc_attr($afwhp_contact7_form) . esc_attr($product->get_id()); ?>_close form_close_btn btn btn-default">X</button>

													<?php echo do_shortcode('[contact-form-7 id="' . $afwhp_contact7_form . '" title="' . $form_title . '" ] '); ?>

												</div>

												<?php
												return;
											} else {

												echo '<a href="javascript:void(0)" rel="nofollow" class="button add_to_cart_button product_type_' . esc_attr($product->get_type()) . '">' . esc_attr($afwhp_custom_button_text) . '</a>';
												return;
											}
											
										} 
									}

								}

							}
						}




					}

				}

				

			}
		}



		public function check_required_addons( $product_id ) {
			// No parent add-ons, but yes to global.
			if (in_array('woocommerce-product-addons/woocommerce-product-addons.php', apply_filters('active_plugins', get_option('active_plugins'))) ) {
				$addons = WC_Product_Addons_Helper::get_product_addons( $product_id, false, false, true );

				if ( $addons && ! empty( $addons ) ) {
					foreach ( $addons as $addon ) {
						if ( isset( $addon['required'] ) && '1' == $addon['required'] ) {
							return true;
						}
					}
				}
			}

			return false;
		}


	}

	new Addify_Woo_Hide_Price_Front();
}
