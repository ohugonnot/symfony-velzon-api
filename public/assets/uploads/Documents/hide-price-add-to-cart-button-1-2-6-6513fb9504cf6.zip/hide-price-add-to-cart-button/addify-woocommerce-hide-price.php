<?php
/*
	* Plugin Name: Hide Price and Add to Cart Button
	* Plugin URI: https://woocommerce.com/products/hide-price-add-to-cart-button/
	* Description: Use this extension to hide pricing and "add to cart" buttons on specific products and categories. Choose to hide them for non-logged-in, registered customers, or by user roles. Replace prices with custom text and cart buttons with contact forms or custom buttons that link to the page of your choice.
	* Author: Addify
	* Author URI: http://www.addifypro.com/
	* Text Domain: addify_whp
	* Version: 1.2.6
	* WC requires at least: 3.0.9
	 * WC tested up to: 6.*.*
	*
	* Woo: 5539910:c6d897e5d2a53eb74582bb0e0ff572f7
	*
*/

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if (!in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins'))) ) {

	function afreg_admin_notice() {

		$afrfq_allowed_tags = array(
			'a' => array(
				'class' => array(),
				'href'  => array(),
				'rel'   => array(),
				'title' => array(),
			),
			'b' => array(),

			'div' => array(
				'class' => array(),
				'title' => array(),
				'style' => array(),
			),
			'p' => array(
				'class' => array(),
			),
			'strong' => array(),

		);

		// Deactivate the plugin
		deactivate_plugins(__FILE__);

		$afrfq_woo_check = '<div id="message" class="error">
			<p><strong>Hide Price and Add to Cart Button plugin is inactive.</strong> The <a href="http://wordpress.org/extend/plugins/woocommerce/">WooCommerce plugin</a> must be active for this plugin to work. Please install &amp; activate WooCommerce »</p></div>';
		echo wp_kses( __( $afrfq_woo_check, 'addify_rfq' ), $afrfq_allowed_tags);

	}
	add_action('admin_notices', 'afreg_admin_notice');
}

if (!class_exists('Addify_Woo_Hide_Price') ) {

	class Addify_Woo_Hide_Price {

		public function __construct() {

			$this->afwhp_global_constents_vars();
			
			add_action('wp_loaded', array( $this, 'afwhp_init' ));
			add_action( 'init', array($this, 'afwhp_custom_post_type' ));
			if (is_admin() ) {
				include_once AFWHP_PLUGIN_DIR . 'admin/class-afwhp-admin.php';
			} else {
				include_once AFWHP_PLUGIN_DIR . 'front/class-afwhp-front.php';
			}

			

		}

		

		public function afwhp_global_constents_vars() {

			if (!defined('AFWHP_URL') ) {
				define('AFWHP_URL', plugin_dir_url(__FILE__));
			}

			if (!defined('AFWHP_BASENAME') ) {
				define('AFWHP_BASENAME', plugin_basename(__FILE__));
			}

			if (! defined('AFWHP_PLUGIN_DIR') ) {
				define('AFWHP_PLUGIN_DIR', plugin_dir_path(__FILE__));
			}
		}

		public function afwhp_init() {
			if (function_exists('load_plugin_textdomain') ) {
				load_plugin_textdomain('addify_whp', false, dirname(plugin_basename(__FILE__)) . '/languages/');
			}
		}

		public function afwhp_custom_post_type() {

			$labels = array(
				'name'                => esc_html__('Hide Price & Add to Cart Button', 'addify_whp'),
				'singular_name'       => esc_html__('Hide Price & Add to Cart Button', 'addify_whp'),
				'add_new'             => esc_html__('Add New Rule', 'addify_whp'),
				'add_new_item'        => esc_html__('Add New Rule', 'addify_whp'),
				'edit_item'           => esc_html__('Edit Rule', 'addify_whp'),
				'new_item'            => esc_html__('New Rule', 'addify_whp'),
				'view_item'           => esc_html__('View Rule', 'addify_whp'),
				'search_items'        => esc_html__('Search Rule', 'addify_whp'),
				'exclude_from_search' => true,
				'not_found'           => esc_html__('No rule found', 'addify_whp'),
				'not_found_in_trash'  => esc_html__('No rule found in trash', 'addify_whp'),
				'parent_item_colon'   => '',
				'all_items'           => esc_html__('All Rules', 'addify_whp'),
				'menu_name'           => esc_html__('Hide Price', 'addify_whp'),
			);

			$args = array(
				'labels' => $labels,
				'menu_icon'  => '',
				'public' => false,
				'publicly_queryable' => true,
				'show_ui' => true,
				'show_in_menu' => false,
				'query_var' => true,
				'rewrite' => true,
				'capability_type' => 'post',
				'has_archive' => true,
				'hierarchical' => false,
				'menu_position' => 30,
				'rewrite' => array('slug' => 'addify_whp', 'with_front'=>false ),
				'supports' => array('title')
			);

			register_post_type( 'addify_whp', $args );

		}

		
	}

	new Addify_Woo_Hide_Price();

}

